<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_Amazon_CatogaryValidation_testSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>b2724e25-4390-4f08-ba8e-8c9a6fd04485</testSuiteGuid>
   <testCaseLink>
      <guid>bdc91dbb-07a6-4ce7-b3ad-5715e01c1ce8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DDT/TC_Validation Amazon Category_Excel_003</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>33e887a8-83c9-42cb-9ec9-94d527d79cb9</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_TestData/Amazon_Testdataexcel_Category</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>33e887a8-83c9-42cb-9ec9-94d527d79cb9</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>category</value>
         <variableId>78c1698f-e7ee-41e9-a346-5fb5c1c9ff75</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>33e887a8-83c9-42cb-9ec9-94d527d79cb9</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>item</value>
         <variableId>3f99a976-f1b4-4de5-83c2-cf66997026af</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>7b3a4944-8424-4c86-bf8c-b1ec36ed12fe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DDT/TC_ValidateAmazon_Login_Internal_002</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>b3650ea7-75a9-4c24-aefa-7b3a1065cd14</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_TestData/Amazon_Testdata_internal_Login</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
