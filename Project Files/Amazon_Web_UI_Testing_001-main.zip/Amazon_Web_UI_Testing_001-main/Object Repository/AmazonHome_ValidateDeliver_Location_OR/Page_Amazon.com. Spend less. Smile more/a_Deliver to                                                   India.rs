<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Deliver to                                                   India</name>
   <tag></tag>
   <elementGuidId>99b02de8-61c3-47d0-93ed-8303147eafb5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-global-location-popover-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-global-location-popover-link']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a07ad010-cfc6-4f20-b18d-b8285cd101ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-global-location-popover-link</value>
      <webElementGuid>a6ef8c0b-4c92-4b4c-b826-bc708b87c322</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 a-popover-trigger a-declarative nav-progressive-attribute</value>
      <webElementGuid>ce0584c9-fab5-420d-82a1-5ebc26293d0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>ca4e8c48-7ad7-499b-b55d-a32642e15543</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
            
                
                   Deliver to
                
                
                   India
                
            
        </value>
      <webElementGuid>578310a0-34b7-47d8-b15a-680150209d30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-global-location-popover-link&quot;)</value>
      <webElementGuid>f470f33c-87d5-4229-bb2a-4f3aae006acd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-global-location-popover-link']</value>
      <webElementGuid>89915c36-d5fe-43f8-8afb-dd01cdbe84f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='nav-global-location-data-modal-action']/a</value>
      <webElementGuid>67e7198b-8f48-46cd-91dc-bc5d1f77f684</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/a</value>
      <webElementGuid>14edb4f7-26b4-480f-9677-6a9f6c899287</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@id = 'nav-global-location-popover-link' and (text() = '
            
            
                
                   Deliver to
                
                
                   India
                
            
        ' or . = '
            
            
                
                   Deliver to
                
                
                   India
                
            
        ')]</value>
      <webElementGuid>e90bbd13-f2f1-49c6-b786-81ddc999abf6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
