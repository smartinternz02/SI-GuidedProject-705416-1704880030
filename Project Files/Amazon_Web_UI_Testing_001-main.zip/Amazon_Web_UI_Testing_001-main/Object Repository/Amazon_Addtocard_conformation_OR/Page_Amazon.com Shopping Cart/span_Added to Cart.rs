<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Added to Cart</name>
   <tag></tag>
   <elementGuidId>a0acb22f-e95d-4a93-bebd-1d1b6eca21e6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-size-medium-plus.a-color-base.sw-atc-text.a-text-bold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>522bd2cb-3ba7-4dc1-9e93-5d19fd5987d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus a-color-base sw-atc-text a-text-bold</value>
      <webElementGuid>4437b5fd-e415-49b3-b821-9dc11bdf945a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            Added to Cart
        
    </value>
      <webElementGuid>a50a5fce-998e-4ed8-bce6-a18c1954ae87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;NATC_SMART_WAGON_CONF_MSG_SUCCESS&quot;)/span[@class=&quot;a-size-medium-plus a-color-base sw-atc-text a-text-bold&quot;]</value>
      <webElementGuid>9ce3c5e5-8b1b-41ea-84c1-77797c982dca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      <webElementGuid>4580002c-e169-4d22-b4bc-164fa74dbfaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/span</value>
      <webElementGuid>6b2a85b3-9d62-487c-924c-68dcb3bd551f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
            Added to Cart
        
    ' or . = '
        
            Added to Cart
        
    ')]</value>
      <webElementGuid>2695e54f-571a-4feb-a82c-719bc14bdd3a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
