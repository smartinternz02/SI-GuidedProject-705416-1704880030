<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Theres already an account with this ema_a5b427</name>
   <tag></tag>
   <elementGuidId>b0dc48cb-e9fa-4cdb-b366-a3d0987a5024</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#register-mase-inlineerror > div.a-box-inner.a-alert-container > div.a-alert-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='register-mase-inlineerror']/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1cd9804a-a9e4-4ffd-9b8b-2f4e8ebae442</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-alert-content</value>
      <webElementGuid>be67c533-1577-4326-ba07-fc17d5aa1b5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      There's already an account with this email. Sign in or learn more.
    </value>
      <webElementGuid>5cc1e7d6-61ba-48a5-bdc2-3475451d86cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;register-mase-inlineerror&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]</value>
      <webElementGuid>6f605d5c-727e-4749-a58e-4b71e603199b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='register-mase-inlineerror']/div/div</value>
      <webElementGuid>c8723115-1592-4d1b-95fe-29742e4306f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>8a23cd9c-15f5-4ab5-8390-04cf7eedb518</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
      There&quot; , &quot;'&quot; , &quot;s already an account with this email. Sign in or learn more.
    &quot;) or . = concat(&quot;
      There&quot; , &quot;'&quot; , &quot;s already an account with this email. Sign in or learn more.
    &quot;))]</value>
      <webElementGuid>e55ef3d4-13e3-4881-bcc9-c570014ac643</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
