<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Todays Deals                        Cou_7c1b01</name>
   <tag></tag>
   <elementGuidId>70088008-498b-42e3-a655-bd5472514897</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-subnav</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-subnav']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>df619934-222f-47dc-bc5c-88c398078801</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-subnav</value>
      <webElementGuid>96d802b8-e8f6-4f47-a37d-50909963dd83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-category</name>
      <type>Main</type>
      <value>goldbox</value>
      <webElementGuid>37030422-7bbb-4d28-80d9-b27c66785c7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  
    
      Today's Deals
      
    
  
  
    
      Coupons
      
    
  
  
    
      Renewed Deals
      
    
  
  
    
      Outlet
      
    
  
  
    
      Digital Deals
      
    
  
  
    
      Amazon Warehouse
      
    
  

</value>
      <webElementGuid>18b3d94e-61d5-4707-a245-66434d57cb34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-subnav&quot;)</value>
      <webElementGuid>5e292b7e-cbd0-4ae2-b674-ed9657430eb0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='nav-subnav']</value>
      <webElementGuid>41023dd4-59ee-477e-8dac-5d34c91cd9a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-progressive-subnav']/div</value>
      <webElementGuid>a42d7fd3-b770-474e-8666-6aa49e8d5c74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div</value>
      <webElementGuid>82f68371-a5b6-4a88-92d4-ebb93540361b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'nav-subnav' and (text() = concat(&quot;
  
    
      Today&quot; , &quot;'&quot; , &quot;s Deals
      
    
  
  
    
      Coupons
      
    
  
  
    
      Renewed Deals
      
    
  
  
    
      Outlet
      
    
  
  
    
      Digital Deals
      
    
  
  
    
      Amazon Warehouse
      
    
  

&quot;) or . = concat(&quot;
  
    
      Today&quot; , &quot;'&quot; , &quot;s Deals
      
    
  
  
    
      Coupons
      
    
  
  
    
      Renewed Deals
      
    
  
  
    
      Outlet
      
    
  
  
    
      Digital Deals
      
    
  
  
    
      Amazon Warehouse
      
    
  

&quot;))]</value>
      <webElementGuid>20c3993b-1e53-45ae-b4b6-0a87a0a27fb7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
